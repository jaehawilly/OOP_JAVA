public class Ex4 {
    public static void main(String[] args) {
        Gate[] gate = { new andGate(true, false),
                new orGate(true, false),
                new xorGate(true, false) };
        for(Gate g : gate) {
            System.out.println(g.operator() + " = " + g.operation());
        }
    }
}
class andGate extends Gate {
    public andGate(boolean x, boolean y) {
        super(x,y);
    }
    @Override
    public boolean operation() { return (x&y); }
    @Override
    public String operator() { return x + " & " + y; }
}
class orGate extends Gate {
    public orGate(boolean x, boolean y) {
        super(x,y);
    }
    @Override
    public boolean operation() { return (x|y); }
    @Override
    public String operator() { return x + " | " + y; }
}
class xorGate extends Gate {
    public xorGate(boolean x, boolean y) {
        super(x,y);
    }
    @Override
    public boolean operation() { return (x^y); }
    @Override
    public String operator() { return x + " ^ " + y; }
}