public class Ex5 {
    // isNumber 메서드를 작성하시오.
    public static boolean isNumber(String str) {
        int len=str.length();
        int cnt=0;
        for(int i=0;i<len;i++) {
            if(str.charAt(i)=='0' || str.charAt(i)=='1' || str.charAt(i)=='2'
             || str.charAt(i)=='3' || str.charAt(i)=='4' || str.charAt(i)=='5'
                    || str.charAt(i)=='6' || str.charAt(i)=='7' || str.charAt(i)=='8' || str.charAt(i)=='9'){
                cnt++;
            }
        }
        if(cnt==len) return true;
        else return false;
    }
    public static void main(String[] args) {
        String str = "123";
        System.out.println(str+"는 숫자입니까? "+isNumber(str));
        str = "1234x";
        System.out.println(str+"는 숫자입니까? "+isNumber(str));
    }
}
