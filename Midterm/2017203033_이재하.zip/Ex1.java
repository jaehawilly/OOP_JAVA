import java.util.Scanner;

public class Ex1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("두 개의 정수 입력 : ");
        String str=sc.nextLine();
        String s[]=str.split(" ");
        int cnt=0;
        for(int i=0;i<s[0].length();i++) {
            if(s[0].charAt(i)==s[1].charAt(0))
                cnt++;
        }
        System.out.println("count : " + cnt);
    }
}
