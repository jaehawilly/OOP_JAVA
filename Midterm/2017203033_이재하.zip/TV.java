public class TV {
    int size;
    public TV(int size) {
        this.size=size;
    }
    int getSize() { return size; }
    void setSize(int size) { this.size=size; }
}
