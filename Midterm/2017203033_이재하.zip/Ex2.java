public class Ex2 {
    public static void main(String[] args) {
        int[] A = { 7, 5, 3, 1, -1 };
        int[] B = { 3, 2, 1, 0, -1, -2 };
        int[] C = { 7, 4, 1, -2 };
        int[] R = ArrayUtil.calc(A, B, C);
        System.out.print("(A U B) ∩ C = { " + R[0]);
        for (int i = 1; i < R.length; i++)
            System.out.print(", " + R[i]);
        System.out.println(" }");
    }
}
class ArrayUtil {
    public static int[] calc(int[] a, int[] b, int[] c) {
        int[] temp=new int[a.length+b.length];
        for(int i=0;i<a.length;i++) {
            temp[i]=a[i];
        }
        for(int i=0;i<b.length;i++){
            temp[i+a.length]=b[i];
        }
        int[] mulAB=mul(a,b);
        int[] temp2=sub(temp,mulAB);
        int[] result=mul(temp2,c);
        return result;
    }
    public static int[] mul(int[] arr1, int[] arr2) {
        int[] temp=new int[arr1.length+arr2.length];
        int cnt=0;
        for(int i=0;i<arr1.length;i++){
            for(int j=0;j<arr2.length;j++){
                if(arr1[i]==arr2[j]){
                    temp[cnt]=arr1[i];
                    cnt++;
                }
            }
        }
        return temp;
    }
    public static int[] sub(int[] arr1, int[] arr2) {
        int cnt=0;
        int[] result=new int[arr1.length];
        for(int i=0;i<arr1.length;i++){
            for(int j=0;j<arr2.length;j++){
                if(arr1[i]==arr2[j])
                    break;
                else if(j==arr2.length-1){
                    result[cnt]=arr1[i];
                    cnt++;
                }
            }
        }
        int n=0;
        for(int i=0;i<arr1.length;i++){
            if(result[i]!=0)
                n++;
        }
        int[] r=new int[n];
        for(int i=0;i<n;i++){
            r[i]=result[i];
        }
        return r;
    }
}