public class Gate {
    protected boolean x, y;
    public Gate(boolean x, boolean y) {
        this.x = x; this.y = y;
    }
    public boolean operation() { return true; }
    public String operator() { return null; }
}