public class question3 {
    public static void main(String[] args) {
        int n1=100, n2=3;
        double result;
        result=(double)n1/n2;
        System.out.println(n1 + "/" + n2 + " = " + result);
        System.out.println(n1 + "/" + n2 + " = 몫 " + (int)result + ", 나머지 " + n1%n2);
    }
}