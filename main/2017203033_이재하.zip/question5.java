public class question5 {
    public static void main(String[] args) {
        int n1=12;
        int n2=012;
        int n3=0x12;

        System.out.println("10진수 12\t: " + n1);
        System.out.println("8진수 12 \t: " + n2);
        System.out.println("16진수 12\t: " + n3);
        System.out.println("Sum\t\t\t: " + (n1+n2+n3));
        System.out.println("Average\t\t: " + (n1+n2+n3)/3);

    }
}