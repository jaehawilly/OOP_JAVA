public class question2 {
    public static void main(String[] args) {
        System.out.println("안녕하세요!" + "\n" + "저는 홍길동입니다." + "\n\n" + "반갑습니다.");
    }
}