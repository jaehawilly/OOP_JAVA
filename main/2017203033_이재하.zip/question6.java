public class question6 {
    public static void main(String[] args) {
        byte n1=0B00101111;
        byte n2=0B00010101;
        System.out.println("& 결과 : " + (n1&n2));
        System.out.println("| 결과 : " + (n1|n2));
    }
}