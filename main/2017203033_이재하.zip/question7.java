public class question7 {
    public static void main(String[] args) {
        int num=3;
        System.out.println("result : " + ((num<<(num+1))-num));
    }
}